from django.apps import AppConfig


class CollsConfig(AppConfig):
    name = 'colls'
