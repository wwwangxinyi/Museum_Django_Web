from django.contrib import admin
from colls.models import Coll

# Register your models here.

admin.site.register(Coll)